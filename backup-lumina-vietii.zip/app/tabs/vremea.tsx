import React, { useEffect, useState, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";

const API_KEY = "1400ca456e470d6a5d5a94c0fdb6766d";

// 🔹 Formatare frumoasă pentru descriere meteo
const prettify = (s?: string) =>
  (s || "")
    .replace(/\s+/g, " ")
    .trim()
    .split(" ")
    .map((w) => (w ? w[0].toUpperCase() + w.slice(1) : ""))
    .join(" ");

export default function VremeaScreen() {
  const router = useRouter();
  const [weather, setWeather] = useState<any>(null);
  const [forecast, setForecast] = useState<any[]>([]);

  // Animații fade + zoom pentru temperatura principală
  const fadeTemp = useRef(new Animated.Value(0)).current;
  const scaleTemp = useRef(new Animated.Value(0.9)).current;

  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const res = await fetch(
          `https://api.openweathermap.org/data/2.5/forecast?lat=44.08&lon=26.63&appid=${API_KEY}&units=metric&lang=ro`
        );
        const data = await res.json();

        if (data?.list) {
          const dailyData = data.list.filter((item: any) =>
            item.dt_txt.includes("12:00:00")
          );
          setForecast(dailyData);
          setWeather({
            temp: data.list[0].main.temp,
            desc: data.list[0].weather[0].description,
            icon: data.list[0].weather[0].main, // „Clouds”, „Clear” etc.
          });

          Animated.parallel([
            Animated.timing(fadeTemp, {
              toValue: 1,
              duration: 800,
              useNativeDriver: true,
            }),
            Animated.spring(scaleTemp, {
              toValue: 1,
              friction: 4,
              tension: 60,
              useNativeDriver: true,
            }),
          ]).start();
        } else {
          console.log("⚠️ Structura răspunsului meteo:", data);
        }
      } catch (err) {
        console.log("Eroare vreme:", err);
      }
    };

    fetchWeather();
  }, []);

  if (!weather)
    return (
      <View style={styles.loading}>
        <Text style={{ color: "#1E2A78" }}>Se încarcă prognoza...</Text>
      </View>
    );

  // Selectăm o iconiță Ionicons potrivită
  const weatherIcons: any = {
    Clear: "sunny-outline",
    Clouds: "cloud-outline",
    Rain: "rainy-outline",
    Snow: "snow-outline",
    Thunderstorm: "thunderstorm-outline",
    Drizzle: "partly-sunny-outline",
    Mist: "cloudy-outline",
    Fog: "cloudy-outline",
  };

  const mainIcon = weatherIcons[weather.icon] || "partly-sunny-outline";

  return (
    <ScrollView style={styles.container}>
      {/* 🔹 Bara de sus */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Prognoza Meteo</Text>
      </View>

      {/* 🔸 Temperatura curentă */}
      <View style={styles.currentBox}>
        <Ionicons
          name={mainIcon}
          size={90}
          color="#F9C846"
          style={{ marginBottom: 8, opacity: 0.9 }}
        />

        <Animated.Text
          style={[
            styles.currentTemp,
            { opacity: fadeTemp, transform: [{ scale: scaleTemp }] },
          ]}
        >
          {Math.round(weather.temp)}°C
        </Animated.Text>

        <Animated.Text
          style={[
            styles.currentDesc,
            { opacity: fadeTemp, transform: [{ scale: scaleTemp }] },
          ]}
        >
          {prettify(weather.desc)}
        </Animated.Text>
      </View>

      {/* 🔹 Prognoză 5 zile */}
      <View style={styles.forecastBox}>
        <Text style={styles.subtitle}>Următoarele zile</Text>

        {forecast.map((day, index) => {
          const fade = new Animated.Value(0);
          const date = new Date(day.dt * 1000);
          const dayName = date.toLocaleDateString("ro-RO", { weekday: "long" });
          const main = day.weather[0].main;
          const icon = weatherIcons[main] || "partly-sunny-outline";

          Animated.timing(fade, {
            toValue: 1,
            duration: 500,
            delay: index * 120,
            useNativeDriver: true,
          }).start();

          return (
            <Animated.View
              key={index}
              style={[
                styles.dayRow,
                {
                  opacity: fade,
                  transform: [
                    {
                      translateY: fade.interpolate({
                        inputRange: [0, 1],
                        outputRange: [10, 0],
                      }),
                    },
                  ],
                },
              ]}
            >
              <Text style={styles.dayName}>{dayName}</Text>
              <Ionicons name={icon} size={26} color="#F9C846" />
              <Text style={styles.dayTemp}>
                {Math.round(day.main.temp_min)}° / {Math.round(day.main.temp_max)}°
              </Text>
            </Animated.View>
          );
        })}
      </View>
    </ScrollView>
  );
}

// 🔧 Stiluri
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFF8E1",
    paddingHorizontal: 16,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1E2A78",
    paddingVertical: 14,
    paddingHorizontal: 10,
    borderRadius: 12,
    marginTop: 10,
    marginBottom: 20,
  },
  backButton: {
    backgroundColor: "#F9C846",
    borderRadius: 50,
    padding: 6,
    marginRight: 10,
  },
  headerTitle: {
    color: "#fff",
    fontSize: 20,
    fontWeight: "700",
  },
  currentBox: {
    alignItems: "center",
    backgroundColor: "white",
    borderRadius: 16,
    padding: 30,
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowOffset: { width: 0, height: 2 },
    marginBottom: 25,
  },
  currentTemp: {
    fontSize: 48,
    fontWeight: "bold",
    color: "#1E2A78",
    textAlign: "center",
  },
  currentDesc: {
    fontSize: 17,
    lineHeight: 22,
    color: "#4A5568",
    marginTop: 8,
    textAlign: "center",
    paddingHorizontal: 20,
    maxWidth: 280,
  },
  forecastBox: {
    backgroundColor: "white",
    borderRadius: 14,
    padding: 15,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
  },
  subtitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#1E2A78",
    marginBottom: 10,
    textAlign: "center",
  },
  dayRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 10,
    borderBottomColor: "#eee",
    borderBottomWidth: 1,
  },
  dayName: {
    fontSize: 15,
    color: "#333",
    textTransform: "capitalize",
    width: 100,
  },
  dayTemp: {
    fontSize: 16,
    color: "#1E2A78",
    fontWeight: "600",
  },
  loading: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FFF8E1",
  },
});
